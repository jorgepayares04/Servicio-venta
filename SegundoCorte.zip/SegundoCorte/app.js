const { ifError } = require('assert');
const express = require('express');
const mysql = require('mysql2');
const app = express();
const port = 3000; // Puedes cambiar el número de puerto según tus preferencias

// Configuración de la conexión a la base de datos MySQL
const dbConfig = {
  host: 'localhost',         // Cambia al host de tu base de datos
  user: 'jpayares',          // Reemplaza con tu nombre de usuario de MySQL
  password: 'jorge1999**',   // Reemplaza con tu contraseña de MySQL
  database: `gestion_productos_ventas` // Elimina el punto y coma al final del nombre de la base de datos
};

// Crear una pool de conexiones (recomendado para manejar conexiones de manera eficiente)
const pool = mysql.createPool(dbConfig);

// Middleware para permitir el análisis de datos JSON en las solicitudes
app.use(express.json());

// Iniciar el servidor Express
app.listen(port, () => {
  console.log(`La aplicación está escuchando en el puerto ${port}`);
});

pool.getConnection(function(err,conection){
  if(err)  console.log(`Error ${err}`);
});
// Consultar todos los productos
app.get('/products', (req, res) => {
  pool.query('SELECT * FROM `gestion_productos_ventas`.`productos`', (err, results) => {
    if (err) {
      console.error('Error en la consulta de productos: ' + err);
      res.status(500).json({ error: 'Error en la consulta de productos' });
      return;
    }
    res.json(results);
  });
});

// Consultar un producto por código
app.get('/products/:codigo', (req, res) => {
  const codigo = req.params.codigo;
  pool.query('SELECT * FROM `gestion_productos_ventas`.`productos` WHERE codigo = ?', [codigo], (err, results) => {
    if (err) {
      console.error('Error en la consulta del producto: ' + err);
      res.status(500).json({ error: 'Error en la consulta del producto' });
      return;
    }
    res.json(results[0]);
  });
});

// Consultar todas las ventas
app.get('/sales', (req, res) => {
  pool.query('SELECT * FROM `gestion_productos_ventas`.`ventas`', (err, results) => {
    if (err) {
      console.error('Error en la consulta de ventas: ' + err);
      res.status(500).json({ error: 'Error en la consulta de ventas' });
      return;
    }
    res.json(results);
  });
});

// Consultar una venta por código
app.get('/sales/:codigo', (req, res) => {
  const codigo = req.params.codigo;
  pool.query('SELECT * FROM `gestion_productos_ventas`.`ventas` WHERE codigo = ?', [codigo], (err, results) => {
    if (err) {
      console.error('Error en la consulta de la venta: ' + err);
      res.status(500).json({ error: 'Error en la consulta de la venta' });
      return;
    }
    res.json(results[0]);
  });
});

// Crear un nuevo producto
app.post('/products', (req, res) => {
  const { nombre, descripcion, precio, cantidadEnStock } = req.body;

  const insertQuery = 'INSERT INTO productos (nombre, descripcion, precio, cantidad_en_stock) VALUES (?, ?, ?, ?)';
  const values = [nombre, descripcion, precio, cantidadEnStock];

  pool.query(insertQuery, values, (err, result) => {
    if (err) {
      console.error('Error al crear un producto: ' + err);
      res.status(500).json({ error: 'Error al crear un producto' });
      return;
    }
    res.json({ message: 'Producto creado exitosamente', productId: result.insertId });
  });
});

// Actualizar un producto por código
app.patch('/products/:codigo', (req, res) => {
  const codigo = req.params.codigo;
  const { nombre, descripcion, precio, cantidadEnStock } = req.body;

  const updateQuery = 'UPDATE `gestion_productos_ventas`.`productos` SET nombre = ?, descripcion = ?, precio = ?, cantidad_en_stock = ? WHERE codigo = ?';
  const values = [nombre, descripcion, precio, cantidadEnStock, codigo];

  pool.query(updateQuery, values, (err, result) => {
    if (err) {
      console.error('Error al actualizar un producto: ' + err);
      res.status(500).json({ error: 'Error al actualizar un producto' });
      return;
    }
    res.json({ message: 'Producto actualizado exitosamente' });
  });
});

// Eliminar un producto por código
app.delete('/products/:codigo', (req, res) => {
  const codigo = req.params.codigo;

  const deleteQuery = 'DELETE FROM `gestion_productos_ventas`.`productos` WHERE codigo = ?';

  pool.query(deleteQuery, [codigo], (err, result) => {
    if (err) {
      console.error('Error al eliminar un producto: ' + err);
      res.status(500).json({ error: 'Error al eliminar un producto' });
      return;
    }
    res.json({ message: 'Producto eliminado exitosamente' });
  });
});

// Crear una nueva venta
app.post('/sales', (req, res) => {
  const { codigo_producto, nombre_cliente, telefono_cliente, fecha_venta, cantidad_vendida, total_venta } = req.body;

  const insertQuery = 'INSERT INTO `gestion_productos_ventas`.`ventas` (codigo_producto, nombre_cliente, telefono_cliente, fecha_venta, cantidad_vendida, total_venta) VALUES (?, ?, ?, ?, ?, ?)';
  const values = [codigo_producto, nombre_cliente, telefono_cliente, fecha_venta, cantidad_vendida, total_venta];

  pool.query(insertQuery, values, (err, result) => {
    if (err) {
      console.error('Error al crear una venta: ' + err);
      res.status(500).json({ error: 'Error al crear una venta' });
      return;
    }
    res.json({ message: 'Venta creada exitosamente', saleId: result.insertId });
  });
});

// Actualizar una venta por código
app.patch('/sales/:codigo', (req, res) => {
  const codigo = req.params.codigo;
  const { codigo_producto, nombre_cliente, telefono_cliente, fecha_venta, cantidad_vendida, total_venta } = req.body;

  const updateQuery = 'UPDATE `gestion_productos_ventas`.`ventas` SET codigo_producto = ?, nombre_cliente = ?, telefono_cliente = ?, fecha_venta = ?, cantidad_vendida = ?, total_venta = ? WHERE codigo = ?';
  const values = [codigo_producto, nombre_cliente, telefono_cliente, fecha_venta, cantidad_vendida, total_venta, codigo];

  pool.query(updateQuery, values, (err, result) => {
    if (err) {
      console.error('Error al actualizar una venta: ' + err);
      res.status(500).json({ error: 'Error al actualizar una venta' });
      return;
    }
    res.json({ message: 'Venta actualizada exitosamente' });
  });
});

// Eliminar una venta por código
app.delete('/sales/:codigo', (req, res) => {
  const codigo = req.params.codigo;

  const deleteQuery = 'DELETE FROM `gestion_productos_ventas`.`ventas` WHERE codigo = ?';

  pool.query(deleteQuery, [codigo], (err, result) => {
    if (err) {
      console.error('Error al eliminar una venta: ' + err);
      res.status(500).json({ error: 'Error al eliminar una venta' });
      return;
    }
    res.json({ message: 'Venta eliminada exitosamente' });
  });
});

// Ruta de ejemplo
app.get('/', (req, res) => {
  res.send('¡Hola, mundo desde Express y MySQL!');
});
